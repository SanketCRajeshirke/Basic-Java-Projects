package com.jbk.collectionframework;

import java.util.LinkedList;
import java.util.List;

public class LinkedListDemo {

	public static void main(String[] args) {
		
		List<Integer> nums = new LinkedList<>();
		nums.add(1);
		nums.add(2);
		nums.add(3);
		nums.add(4);
		
		for(int i = 0 ; i<= 3 ;i++) {
			System.out.println(nums.get(i));
		}
	}
}
