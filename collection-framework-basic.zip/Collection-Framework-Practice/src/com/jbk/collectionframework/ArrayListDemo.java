package com.jbk.collectionframework;

import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		//List methods-> add() addAll() remove() removeAll() isEmpty() contains() get() size() clear()
		//get() only in list because list have indexing
		List<Integer> firstFiveNums = new ArrayList<>();
		
		for(int i = 1; i<=6;i++) {
		// add() used to add single object in collection
			firstFiveNums.add(i);
		}
		System.out.println("first five nums collection : "+firstFiveNums);
		
		//remove(index) used to remove single object from collection using index
		//remove(object) used to remove single object using actual object
		firstFiveNums.remove(5);
		System.out.println("first five nums collection after remove() : "+firstFiveNums);
		
		List<Integer> firstTenNums = new ArrayList<>();
		
		List<Integer> nextFiveNums = new ArrayList<>();
		
		for(int i = 6 ; i<=10 ; i++) {
			nextFiveNums.add(i);
		}
		System.out.println("next Five nums collection : "+nextFiveNums);
		
		
		//addAll(collection) used to add collection in another collection
		firstTenNums.addAll(firstFiveNums);
		
		System.out.println("first ten nums collection after adding first five nums collection : "+firstTenNums);
		
		//addAll(index,collection) used to add collection in collection index is used to specify base index
		firstTenNums.addAll(5,nextFiveNums);
		System.out.println("first ten nums collection after adding next five nums collection : "+firstTenNums);
		
		//Creating new ArrayList collection for removeAll()
		List<Integer> oddNums = new ArrayList<>();
		for(int n = 1 ; n<=10 ; n++) {
			if(n%2 !=0) {
				oddNums.add(n);
			}
		}
		//iterating array using for each / getting out objects from collection /another way to get collection objects without get()
		
		for(Integer odd : oddNums) {
				while(odd == 1 ) {
					System.out.print("oddNums collection: ");
					break;
				}
			System.out.print(odd+" ");
		}
		System.out.println();
		
		//removeAll() is used to remove collection from collection / group of objects
		firstTenNums.removeAll(oddNums);
		System.out.println("first ten nums colection after removeing oddNums collection from it: "+firstTenNums);
		
		//isEmpty() method is used to check collection is empty or not? true if empty otherwise false
		System.out.println("isEmpty() method called : "+oddNums.isEmpty());
		
		//size() is used to check size of collection returns 0 if collection is empty otherwise returns size
		System.out.println("size() method called to check size  of collection : "+oddNums.size());
		
		//cotains() is used to check given available object in collection true is avl 
		System.out.println("contains() method called to check given object in collection: "+oddNums.contains(1));
		
		//get(index) is used to get single object in list using index it is present only in List because list have index.
		System.out.println("get() call to get object on specific index : "+ oddNums.get(0));
		
		//clear() is used to clear or to empty the collection
		oddNums.clear();
		System.out.println("after clear() call on oddNums collection: ");
		System.out.println("oddNums.size() call: "+oddNums.size());
		System.out.println("oddNums.isEmpty() call: "+oddNums.isEmpty());
	}

}
