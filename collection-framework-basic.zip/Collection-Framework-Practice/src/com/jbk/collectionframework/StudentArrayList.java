package com.jbk.collectionframework;

import java.util.ArrayList;
import java.util.List;

public class StudentArrayList {

	public static void main(String[] args) {
		
		List<Student> students = new ArrayList<>();
		
		Student sanket = new Student(1, "sanket", 95.65);
		Student saloni = new Student(2, "saloni", 95.68);
		Student aditya = new Student(3,"aditya" , 96.55);
		
		students.add(sanket);
		students.add(saloni);
		students.add(aditya);
		
		for (Student student : students) {
			System.out.println(student);
		}

	}

}
