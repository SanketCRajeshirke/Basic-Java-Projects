package com.jbk.collectionframework;

import java.util.List;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		
		//List methods-> add() addAll() remove() removeAll() isEmpty() contains() get() size() clear()
		//get() only in list because list have indexing
		
		List<Integer> nums= new Vector<>() ;
		nums.add(1);
		nums.add(2);
		nums.add(3);
		nums.add(4);
		
		for(Integer i : nums) {
			System.out.println(i);
		}
	}

}
