package com.jbk.jdbc.statement;

import java.sql.*;

public class CheckCon {

	public static void main(String[] args) throws Exception{
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc", "root", "root");

		System.out.println("con successfull!!");
		
		con.close();
	}

}
