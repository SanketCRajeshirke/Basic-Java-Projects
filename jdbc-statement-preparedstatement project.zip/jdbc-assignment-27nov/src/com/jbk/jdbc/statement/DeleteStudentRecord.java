package com.jbk.jdbc.statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DeleteStudentRecord {

	public static void main(String[] args) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");

		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc","root","root");
		
		String query = "delete  from student where rollno = 3";
		
		Statement stm  = con.createStatement();
		    
		int record = stm.executeUpdate(query);
		System.out.println(record+"record deleted from database");
	
		con.close();
		stm.close();

	}

}
