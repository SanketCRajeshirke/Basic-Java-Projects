package com.jbk.jdbc.statement;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;


public class InsertStudentRecord {

	public static void main(String[] args) throws Exception{
		
		Class.forName("com.mysql.jdbc.Driver");

		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc","root","root");
		
		String query = "insert into student values('sahil',72.83,3)";
		
		Statement stm  = con.createStatement();
		    
		int record = stm.executeUpdate(query);
		System.out.println(record+"record inserted into database");
	
		con.close();
		stm.close();
		
	}

}
