package com.jbk.jdbc.statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class UpdateStudentRecord {

	public static void main(String[] args) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");

		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc","root","root");
		
		String query = "update student set name = 'aditya' where rollno = 2";
		
		Statement stm  = con.createStatement();
		    
		int record = stm.executeUpdate(query);
		System.out.println(record+"record updated in database");
	
		con.close();
		stm.close();

	}

}
