package com.jbk.jdbc.preparedstatement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class UpdateStudentRecord {

	public static void main(String[] args) throws Exception{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your RollNo");
		int rollNo = sc.nextInt(); 
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc", "root", "root");
		
		String query = "update student set name ='saloni' ,marks ='87.99' ,rollno ='1' WHERE rollno = ?;";

		
		PreparedStatement stm = con.prepareStatement(query);
		stm.setInt(1, rollNo);
		int record = stm.executeUpdate();
		
		System.out.println(record+"record is updated from database");
		
		con.close();
		stm.close();
	}

}
