package com.jbk.jdbc.preparedstatement;
import java.sql.*;


public class Connectionc {

	public static void main(String[] args) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc", "root", "root");
		
		System.out.println("connection successfull!!!");
		
		con.close();
		
		System.out.println("connection closed!!!!");
		
	}
}
