package com.jbk.jdbc.preparedstatement;

import java.sql.*;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.Connection;

public class InsertStudentRecord {

	public static void main(String[] args) throws Exception{
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Your Name");
		String name = sc.nextLine();
		
		System.out.println("Enter Your Marks");
		double marks = sc.nextDouble();
		
		System.out.println("Enter Your RollNo");
		int rollNo = sc.nextInt(); 
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc", "root", "root");
		
		String query = "insert into student(name,marks,rollno)  values(?,?,?)";
//		System.out.println("connection successfull!!!");
		
		PreparedStatement stm = con.prepareStatement(query);

		stm.setString(1, name);
		stm.setDouble(2,marks);
		stm.setInt(3, rollNo);
		int record = stm.executeUpdate();
		
		System.out.println(record+"record is inserted in database");
		con.close();
		stm.close();
	}
}
